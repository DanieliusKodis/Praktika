﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BendrijosKomunalinesPaslaugos
{
    public partial class Form11 : Form
    {
        IntInt intInt = new IntInt();
        Class6 class6 = new Class6();

        string query11 =
           " DELETE FROM DabVad WHERE Id NOT IN( 0 )";
       
        public Form11()
        {
            InitializeComponent();
        }

        private void Atgal_Click(object sender, EventArgs e)
        {
            class6.Vykdyk(query11);
            Form1 b = new Form1();
            Class1.Switch(this, b);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form12 b = new Form12();
            Class1.Switch(this, b);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form13 b = new Form13();
            Class1.Switch(this, b);
        }
    }
}
