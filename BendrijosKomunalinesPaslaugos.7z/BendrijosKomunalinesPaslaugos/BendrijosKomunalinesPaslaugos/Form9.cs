﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BendrijosKomunalinesPaslaugos
{
    public partial class Form9 : Form
    {
        Class2 populateTable = new Class2();
        
        IvykdykUzklausa2 uzklausa2 = new IvykdykUzklausa2();
        PridetiINT pridetiINT = new PridetiINT();

        string a = "@a";
        string b = "@b";
        string c = "@c";

        string query2 = "Select * FROM Gyv";
        string query3 = "Select * FROM Vadovai";
        string query4 = "INSERT INTO Gyv VALUES(@a,@b,@a,@b)";
        string query5 = "Update NamoGyventojai Set GyventojasID  = (NULL)" +
            "WHERE GyventojasID = @a " +
            "DELETE FROM Gyv " +
            "WHERE Gyv.Id = @a" ;
        string query6 = "INSERT INTO Vadovai VALUES(@a,@b,@a,@b)";
        string query7 =// "Update NamoGyventojai Set GyventojasID  = (NULL)" +
    //"WHERE GyventojasID = @a " +
    "DELETE FROM Vadovai " +
    "WHERE Vadovai.Id = @a";

        public Form9()
        {
            InitializeComponent();
            Class2.print(listBox1, query2, "Vardas",  "Id");
            Class2.print(listBox3, query2, "Pavarde", "Id");
            Class2.print(listBox2, query3, "Vardas" , "Id");
            Class2.print(listBox4, query3, "Pavarde", "Id");
        }

        private void Form9_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'database1DataSet.Gyv' table. You can move, or remove it, as needed.
            this.gyvTableAdapter.Fill(this.database1DataSet.Gyv);

        }
        // keitimo nauja metodas
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox3.SelectedValue = listBox1.SelectedValue;
        }

        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox1.SelectedValue = listBox3.SelectedValue;
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox4.SelectedValue = listBox2.SelectedValue;
        }

        private void listBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox2.SelectedValue = listBox4.SelectedValue;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            pridetiINT.PridetiStringINTid(query5, a, Convert.ToInt32(listBox1.SelectedValue));
            Class2.print(listBox1, query2, "Vardas", "Id");
            Class2.print(listBox3, query2, "Pavarde", "Id");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            IvykdykUzklausa2.UzklausaDuKint(query4, a, b, textBox1.Text, textBox2.Text);
            Class2.print(listBox1, query2, "Vardas", "Id");
            Class2.print(listBox3, query2, "Pavarde", "Id");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            IvykdykUzklausa2.UzklausaDuKint(query6, a, b, textBox4.Text, textBox3.Text);
            Class2.print(listBox2, query3, "Vardas", "Id");
            Class2.print(listBox4, query3, "Pavarde", "Id");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            pridetiINT.PridetiStringINTid(query7, a, Convert.ToInt32(listBox2.SelectedValue));
            Class2.print(listBox2, query3, "Vardas", "Id");
            Class2.print(listBox4, query3, "Pavarde", "Id");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form5 b = new Form5();
            Class1.Switch(this, b);
        }
    }
}
