﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BendrijosKomunalinesPaslaugos
{
    public partial class Form10 : Form
    {
        Class2INT class2int = new Class2INT();
        IntInt intInt = new IntInt();
        string a = "@a";
        string b = "@b";

        string query2 = "Select * FROM Paslaugos ";
        string query3 = "Select * FROM Vadovai ";
        //  string query4 = "Select * FROM Vadovai a"+
        //        "INNER JOIN Paslaugos b ON  Vadovai.Id = b.VadovasID " +       
        //     "WHERE b.Id = @a ";
        string query4 = "SELECT * FROM Vadovai a " +
                       "INNER JOIN Paslaugos b ON a.Id = b.VadovasID " +
               
                       "WHERE b.Id = @a";
        string query5 = "Update Paslaugos Set VadovasID  = @a" +
              " WHERE Id = @b ";
        public Form10()
        {
            InitializeComponent();
            Class2.print(listBox1, query2, "Pavadinimas", "Id");
            Class2.print(listBox3, query3, "Vardas", "Id");
          class2int.printz(listBox2, query4, "Vardas", "Id", a, Convert.ToInt32(listBox1.SelectedValue));
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            intInt.PridetiStringINTINTid(query5,a,b, Convert.ToInt32(listBox3.SelectedValue), Convert.ToInt32(listBox1.SelectedValue));
            class2int.printz(listBox2, query4, "Vardas", "Id", a, Convert.ToInt32(listBox1.SelectedValue));
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            class2int.printz(listBox2, query4, "Vardas", "Id", a, Convert.ToInt32(listBox1.SelectedValue));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form7 b = new Form7();
            Class1.Switch(this, b);
        }
    }
}
