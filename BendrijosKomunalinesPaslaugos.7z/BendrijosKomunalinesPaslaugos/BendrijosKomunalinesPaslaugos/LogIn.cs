﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;


namespace BendrijosKomunalinesPaslaugos
{
     class LogIn
    {
        public static void Prisijungti(string query, string fromQauryA, string fromQauryB,  string username, string pasword,  Form oldForm, Form newForm,  ListBox userID, int id)
        {

            SqlConnection connection;
            string conectionString;
            conectionString = ConfigurationManager.ConnectionStrings["BendrijosKomunalinesPaslaugos.Properties.Settings.Database1ConnectionString"].ConnectionString;



            using (connection = new SqlConnection(conectionString))
            using (SqlCommand comand = new SqlCommand(query, connection))
            using (SqlDataAdapter adapter = new SqlDataAdapter(comand))

            {
                comand.Connection.Open();
                comand.Parameters.AddWithValue(fromQauryA, username);
                comand.Parameters.AddWithValue(fromQauryB, pasword);
                // comand.Parameters.AddWithValue(fromQauryC, naudTipas);
               
                DataTable table = new DataTable();

                adapter.Fill(table);
                userID.ValueMember = "Id";
               

                if (table.Rows.Count != 0)
                { 
                  Class1.Switch(oldForm, newForm);
                }
                comand.ExecuteScalar();
                comand.Connection.Close();
            }

        }



    }
}
