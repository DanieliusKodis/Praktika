﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace BendrijosKomunalinesPaslaugos
{
    public partial class Form5 : Form
    {
        public static int BendrijosID;


        Class1 class1 = new Class1();
        Class2 populateTable = new Class2();
        Prideti prodetiViena = new Prideti();
        IvykdykUzklausa2 uzklausa2 = new IvykdykUzklausa2();





        //
        string a = "@a";
        string b = "@b";






        //Queries
        string query1 = "Select * FROM Bendrija ";
        string query2 = "INSERT INTO Bendrija " +
               "SELECT TOP 1 @a FROM Bendrija WHERE not exists (Select a.Pavadinimas FROM Bendrija a WHERE a.Pavadinimas = @a)";
        string query3 = // bugged out FK11
               "INSERT INTO Bendrija " +
               "SELECT TOP 1 'Klaida-Nepriskirta-Klaida' FROM Bendrija WHERE not exists (Select a.Pavadinimas FROM Bendrija a WHERE a.Pavadinimas = 'Klaida-Nepriskirta-Klaida')" +
          "Update BendrijosPaslaugosNamas Set BendrijosID =  (Select a.Id FROM Bendrija a WHERE a.Pavadinimas = 'Klaida-Nepriskirta-Klaida')" +
          " WHERE BendrijosID = @a " +
               "Update BendrijosPaslaugos Set BendrijosID  = (Select a.Id FROM Bendrija a WHERE a.Pavadinimas = 'Klaida-Nepriskirta-Klaida')" +
               " WHERE BendrijosID = @a " +
            "Update BendrijosPaslaugosNamas Set BendrijosID  = (Select a.Id FROM Bendrija a WHERE a.Pavadinimas = 'Klaida-Nepriskirta-Klaida')" +
               " WHERE BendrijosID = @a " +
          "Update BendrijosPaslaugosKaina Set BendrijosID =  (Select a.Id FROM Bendrija a WHERE a.Pavadinimas = 'Klaida-Nepriskirta-Klaida')" +
          " WHERE BendrijosID = @a " +
             "DELETE FROM Bendrija WHERE Id = @a AND Pavadinimas != 'Klaida-Nepriskirta-Klaida'";

        string query4 = "Update Bendrija Set Pavadinimas = @a WHERE Id = @b ";
        public Form5()
        {
            InitializeComponent();
            Class2.print( listBox1,query1 ,"Pavadinimas", "Id");
          
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Prideti.PridetiStringID(query2, a,  textBox1.Text);
            Class2.print( listBox1, query1, "Pavadinimas", "Id");


        }

        private void button2_Click(object sender, EventArgs e)
        {
            Prideti.PridetiStringID(query3, a, listBox1.SelectedValue.ToString());
            Class2.print(listBox1, query1, "Pavadinimas", "Id");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            IvykdykUzklausa2.UzklausaDuKint(query4, a, b, textBox1.Text, listBox1.SelectedValue.ToString());
            Class2.print(listBox1, query1, "Pavadinimas", "Id");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            label1.Text = listBox1.SelectedValue.ToString();
            BendrijosID = Convert.ToInt32(label1.Text);

            Form7 b = new Form7();
            Class1.Switch(this, b);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form9 b = new Form9();
            Class1.Switch(this, b);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            label1.Text = listBox1.SelectedValue.ToString();
            BendrijosID = Convert.ToInt32(label1.Text);

            Form8 b = new Form8();
            Class1.Switch(this, b);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form1 b = new Form1();
            Class1.Switch(this, b);
        }
    }
}
