﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace BendrijosKomunalinesPaslaugos
{
    class IvykdykUzklausa2
    {
        public static void UzklausaDuKint(string query, string fromQeury, string fromQeury2, string text, string text2)
        {
            SqlConnection connection;
            string conectionString;
            conectionString = ConfigurationManager.ConnectionStrings["BendrijosKomunalinesPaslaugos.Properties.Settings.Database1ConnectionString"].ConnectionString;



            using (connection = new SqlConnection(conectionString))
            using (SqlCommand comand = new SqlCommand(query, connection))


            {
                connection.Open();
                comand.Parameters.AddWithValue(fromQeury, text);
                comand.Parameters.AddWithValue(fromQeury2, text2);

                comand.ExecuteScalar();
            }

        }
    }
}
