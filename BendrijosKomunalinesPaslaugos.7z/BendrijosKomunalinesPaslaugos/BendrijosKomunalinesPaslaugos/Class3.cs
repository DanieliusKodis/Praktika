﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace BendrijosKomunalinesPaslaugos
{
    class Class3
    {
        public static void RodytiPagalID(ListBox box, string displayMember, string valueMember, string query, string fromQeury, string text)
        {
            SqlConnection connection;
            string conectionString;
            conectionString = ConfigurationManager.ConnectionStrings["BendrijosKomunalinesPaslaugos.Properties.Settings.Database1ConnectionString"].ConnectionString;



            using (connection = new SqlConnection(conectionString))
            using (SqlCommand comand = new SqlCommand(query, connection))
            using (SqlDataAdapter adapter = new SqlDataAdapter(comand))
            {
                connection.Open();
                comand.Parameters.AddWithValue(fromQeury, text);

                
                DataTable table = new DataTable();

                adapter.Fill(table); ;

                box.DisplayMember = displayMember;
                box.ValueMember = valueMember;
                box.DataSource = table;

                comand.ExecuteScalar();
            }

        }
    }
}
