﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace BendrijosKomunalinesPaslaugos
{
    class Class2
    {
        
       public static void print( ListBox box, string query, string displayMember, string valueMember)
        {
            SqlConnection connection;
            string conectionString;
            conectionString = ConfigurationManager.ConnectionStrings["BendrijosKomunalinesPaslaugos.Properties.Settings.Database1ConnectionString"].ConnectionString;
            using (connection = new SqlConnection(conectionString))

            using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
         
            {
                
                DataTable table = new DataTable();

                adapter.Fill(table); ;

                box.DisplayMember = displayMember;
                box.ValueMember = valueMember;
                box.DataSource = table;
            }
        }
    }
}
