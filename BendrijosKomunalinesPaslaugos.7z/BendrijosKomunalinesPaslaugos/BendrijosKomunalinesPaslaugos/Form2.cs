﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace BendrijosKomunalinesPaslaugos
{

    public partial class Form2 : Form
    {
        // SqlConnection connection;
        // string conectionString;
        string query6 = "SELECT * FROM DabGyv a ";
        string query = "SELECT * FROM Paslaugos a " +

                                "INNER JOIN BendrijosPaslaugosNamas b ON a.Id = b.PaslaugosID " +
                                 "INNER JOIN Namas e ON e.Id = b.NamoID " +
                                   "INNER JOIN NamoGyventojai f ON f.NamasID = e.Id " +
                                     "INNER JOIN Gyv v ON v.Id = f.GyventojasID " +
                                "WHERE v.Id= 1";

        string query2 = "SELECT * FROM BendrijosPaslaugosKaina a " +
             "INNER JOIN Paslaugos b ON a.PaslaugosID = b.Id " +
                             "INNER JOIN BendrijosPaslaugosNamas c ON b.Id = c.PaslaugosID " +
                              "INNER JOIN Namas e ON e.Id = c.NamoID " +
                                "INNER JOIN NamoGyventojai f ON f.NamasID = e.Id " +
                                  "INNER JOIN Gyv v ON v.Id = f.GyventojasID " +
                             "WHERE v.Id= (Select a.DabGyvID FROM DabGyv a)";
        public Form2()
        {
            InitializeComponent();
            //    conectionString = ConfigurationManager.ConnectionStrings["BendrijosKomunalinesPaslaugos.Properties.Settings.Database1ConnectionString"].ConnectionString;
            //   PopulateRecipes();
            // Class2 class2 = new Class2();
            // DataTable table = new DataTable();
            // class2.printPaslaugas(table, Paslaugos);
            Class2.print(Paslaugos, query, "Pavadinimas", "Id");
            Class2.print(Kaina, query2, "Kaina", "Id");
            Class2.print(listBox1, query6, "DabGyvID", "Id");
        }
        private void Paslaugos_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

    }
}
