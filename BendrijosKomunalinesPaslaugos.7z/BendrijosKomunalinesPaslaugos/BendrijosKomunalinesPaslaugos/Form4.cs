﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace BendrijosKomunalinesPaslaugos
{
    public partial class Form4 : Form
    {
        Class1 class1 = new Class1();
        public Form4()
        {
            InitializeComponent();
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form5 b = new Form5();
            Class1.Switch(this, b);
        }

        private void label1_Click(object sender, EventArgs e)
        {
           
        }
    }
}
