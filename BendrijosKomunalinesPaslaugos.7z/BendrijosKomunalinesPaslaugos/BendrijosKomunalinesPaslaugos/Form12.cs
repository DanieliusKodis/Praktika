﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace BendrijosKomunalinesPaslaugos
{
    public partial class Form12 : Form
    {
        IntInt intInt = new IntInt();
        PridetiINT pridetiINT = new PridetiINT();
      
        Class5 class5 = new Class5();
        Class2INT class2INT = new Class2INT();
        string query2 = "Select * FROM Bendrija ";
        string query3 = "SELECT * FROM Paslaugos a " +
                  "INNER JOIN BendrijosPaslaugosKaina b ON a.Id = b.PaslaugosID " +
            "INNER JOIN Bendrija c ON c.id = b.BendrijosID " +
                  "WHERE c.Id = @a AND a.VadovasID = (Select a.DabVadID FROM DabVad a)";
        string query4 = "Select * From BendrijosPaslaugosKaina a " +
             "INNER JOIN Paslaugos b ON a.PaslaugosID = b.Id " +
            "WHERE a.BendrijosID = @a AND b.VadovasID = (Select a.DabVadID FROM DabVad a) ";
        string query5 = "Update BendrijosPaslaugosKaina Set Kaina  = @a" +
              " WHERE PaslaugosID = @b AND BendrijosID = @C ";

      
        public Form12()
        {
            InitializeComponent();

            Class2.print(listBox1, query2, "Pavadinimas", "Id");

            class2INT.printz(listBox3, query4, "Kaina", "Id", "@a", Convert.ToInt32(listBox1.SelectedValue));

            class2INT.printz(listBox2, query3, "Pavadinimas", "Id",  "@a", Convert.ToInt32(listBox1.SelectedValue));
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            class5.UzklausaTriKint(query5, "@a", "@b", "@c", Convert.ToInt32(textBox1.Text), Convert.ToInt32(listBox2.SelectedValue), Convert.ToInt32(listBox1.SelectedValue));
            class2INT.printz (listBox3, query4, "Kaina", "Id",  "@a", Convert.ToInt32(listBox1.SelectedValue));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form11 b = new Form11();
            Class1.Switch(this, b);
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            class2INT.printz(listBox3, query4, "Kaina", "Id", "@a", Convert.ToInt32(listBox1.SelectedValue));

            class2INT.printz(listBox2, query3, "Pavadinimas", "Id", "@a", Convert.ToInt32(listBox1.SelectedValue));
        }
    }
}
