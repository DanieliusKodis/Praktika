﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace BendrijosKomunalinesPaslaugos
{
    class Class5
    {
        
            public void UzklausaTriKint(string query, string fromQeury, string fromQeury2, string fromQeury3, int text, int text2, int text3)
            {
                SqlConnection connection;
                string conectionString;
                conectionString = ConfigurationManager.ConnectionStrings["BendrijosKomunalinesPaslaugos.Properties.Settings.Database1ConnectionString"].ConnectionString;



                using (connection = new SqlConnection(conectionString))
                using (SqlCommand comand = new SqlCommand(query, connection))


                {
                    connection.Open();
                    comand.Parameters.AddWithValue(fromQeury, text);
                    comand.Parameters.AddWithValue(fromQeury2, text2);
                    comand.Parameters.AddWithValue(fromQeury3, text3);
                    comand.ExecuteScalar();
                }

            }
        
    }
}
