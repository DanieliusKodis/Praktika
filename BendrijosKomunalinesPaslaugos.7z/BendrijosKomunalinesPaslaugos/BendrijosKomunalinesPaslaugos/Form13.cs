﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BendrijosKomunalinesPaslaugos
{
    public partial class Form13 : Form
    {
        Class5 class5 = new Class5();

        string query2 = "Select * FROM Bendrija ";
        string query6 = "SELECT * FROM Paslaugos a " +
                  "INNER JOIN BendrijosPaslaugosKaina b ON a.Id = b.PaslaugosID " +
            "INNER JOIN Bendrija c ON c.id = b.BendrijosID " +
                  "WHERE c.Id = @a";
        string query7 = "SELECT * FROM Namas a " +
                "INNER JOIN BendrijosPaslaugosNamas b ON a.Id = b.NamoID " +
          "INNER JOIN Bendrija c ON c.id = b.BendrijosID " +
                "WHERE c.Id = @a";
    
        string query8 = "SELECT * FROM Paslaugos a " +
              "INNER JOIN BendrijosPaslaugosNamas b ON a.Id = b.PaslaugosID " +
        "INNER JOIN Namas c ON c.id = b.NamoID " +
              "WHERE c.Id = @a";
        string query9 = " INSERT INTO BendrijosPaslaugosNamas " +
              "SELECT TOP 1 @a,@b,@c FROM  BendrijosPaslaugosNamas WHERE not exists (Select * FROM BendrijosPaslaugosNamas a Where a.BendrijosID = @a AND a.PaslaugosID = @b AND a.NamoID = @c) ";
        string query10 =

           "DELETE FROM BendrijosPaslaugosNamas WHERE BendrijosID = @a AND PaslaugosID = @b AND NamoID = @c";
        public Form13()
        {
            InitializeComponent();
            Class2.print(listBox1, query2, "Pavadinimas", "Id");
            Class3.RodytiPagalID(listBox2, "Adresas", "Id", query7, "@a", listBox1.SelectedValue.ToString());
            Class3.RodytiPagalID(listBox4, "Pavadinimas", "Id", query6, "@a", listBox1.SelectedValue.ToString());
            Class3.RodytiPagalID(listBox3, "Pavadinimas", "Id", query8, "@a", listBox2.SelectedValue.ToString());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            class5.UzklausaTriKint(query9, "@a", "@b", "@c", Convert.ToInt32(listBox1.SelectedValue), Convert.ToInt32(listBox4.SelectedValue), Convert.ToInt32(listBox2.SelectedValue));
            Class3.RodytiPagalID(listBox3, "Pavadinimas", "Id", query8, "@a", listBox2.SelectedValue.ToString());
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Class3.RodytiPagalID(listBox4, "Pavadinimas", "Id", query6, "@a", listBox1.SelectedValue.ToString());
            Class3.RodytiPagalID(listBox2, "Adresas", "Id", query7, "@a", listBox1.SelectedValue.ToString());
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            Class3.RodytiPagalID(listBox3, "Pavadinimas", "Id", query8, "@a", listBox2.SelectedValue.ToString());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            class5.UzklausaTriKint(query10, "@a", "@b", "@c", Convert.ToInt32(listBox1.SelectedValue), Convert.ToInt32(listBox3.SelectedValue), Convert.ToInt32(listBox2.SelectedValue));
            Class3.RodytiPagalID(listBox3, "Pavadinimas", "Id", query8, "@a", listBox2.SelectedValue.ToString());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form11 b = new Form11();
            Class1.Switch(this, b);
        }
    }
}
