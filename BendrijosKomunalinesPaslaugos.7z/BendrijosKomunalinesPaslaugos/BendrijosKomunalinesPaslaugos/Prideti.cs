﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace BendrijosKomunalinesPaslaugos
{
    class Prideti
    {
        public static void PridetiStringID(string query, string fromQeury,string text )
        {
            SqlConnection connection;
            string conectionString;
            conectionString = ConfigurationManager.ConnectionStrings["BendrijosKomunalinesPaslaugos.Properties.Settings.Database1ConnectionString"].ConnectionString;
          

               
            using (connection = new SqlConnection(conectionString))
            using (SqlCommand comand = new SqlCommand(query, connection))

            {
                connection.Open();
                comand.Parameters.AddWithValue(fromQeury, text);
                

                comand.ExecuteScalar();
            }
  
        }
    }
}
