﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;

namespace BendrijosKomunalinesPaslaugos
{
    class ModifikuotiDuLaukus
    {
        public void Modifikavimas2(string query, string a, string b, string c, string d, int ee, string f)
        {

            SqlConnection connection;
            string conectionString;
            conectionString = ConfigurationManager.ConnectionStrings["BendrijosKomunalinesPaslaugos.Properties.Settings.Database1ConnectionString"].ConnectionString;

            using (connection = new SqlConnection(conectionString))
            using (SqlCommand comand = new SqlCommand(query, connection))

            {
                connection.Open();
                comand.Parameters.AddWithValue(a, d);
                comand.Parameters.AddWithValue(b, ee);
                comand.Parameters.AddWithValue(c, f);
   
                comand.ExecuteScalar();
            }


        }
    }
}
