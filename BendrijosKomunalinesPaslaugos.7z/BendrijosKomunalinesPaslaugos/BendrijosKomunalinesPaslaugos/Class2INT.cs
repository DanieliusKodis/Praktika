﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace BendrijosKomunalinesPaslaugos
{
    class Class2INT
    {
        public  void printz(ListBox box, string query, string displayMember, string valueMember, string fromQeury, int id)
        {
            SqlConnection connection;
            string conectionString;
            conectionString = ConfigurationManager.ConnectionStrings["BendrijosKomunalinesPaslaugos.Properties.Settings.Database1ConnectionString"].ConnectionString;
            using (connection = new SqlConnection(conectionString))
           
            using (SqlCommand comand = new SqlCommand(query, connection))
            using (SqlDataAdapter adapter = new SqlDataAdapter(comand))

            {
                connection.Open();
                DataTable table = new DataTable();

                comand.Parameters.AddWithValue(fromQeury, id);
                comand.ExecuteScalar();

                adapter.Fill(table); 

                box.DisplayMember = displayMember;
                box.ValueMember = valueMember;
                box.DataSource = table;

               
                
            }
        }
    }
}
