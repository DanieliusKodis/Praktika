﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BendrijosKomunalinesPaslaugos
{
    public partial class Form6 : Form
    {
        Class1 class1 = new Class1();
        Class2 populateTable = new Class2();
        Prideti prodetiViena = new Prideti();
        IvykdykUzklausa2 uzklausa2 = new IvykdykUzklausa2();


        string a = "@a";
        string b = "@b";


        string query1 = "Select * FROM Bendrija ";
        string query2 = "Select * FROM Paslaugos ";
        string query3 = "INSERT INTO Paslaugos " +
             "SELECT TOP 1 @a FROM Paslaugos WHERE not exists (Select a.Pavadinimas FROM Paslaugos a WHERE a.Pavadinimas = @a)";
        string query4 =
             "INSERT INTO Paslaugos " +
             "SELECT TOP 1 'Klaida-Nepriskirta-Klaida' FROM Paslaugos WHERE not exists (Select a.Pavadinimas FROM Paslaugos a WHERE a.Pavadinimas = 'Klaida-Nepriskirta-Klaida')" +

             "Update BendrijosPaslaugos Set PaslaugosID  = (Select a.Id FROM Paslaugos a WHERE a.Pavadinimas = 'Klaida-Nepriskirta-Klaida')" +
             " WHERE PaslaugosID = @a " +
          "Update BendrijosPaslaugosNamas Set PaslaugosID  = (Select a.Id FROM Paslaugos a WHERE a.Pavadinimas = 'Klaida-Nepriskirta-Klaida')" +
             " WHERE Paslaugos = @a " +
           "DELETE FROM Paslaugos WHERE Id = @a AND Pavadinimas != 'Klaida-Nepriskirta-Klaida'";

        string query5 = "Update Paslaugos Set Pavadinimas = @a WHERE Id = @b "; // galimi duplikatai

        public Form6()
        {
            InitializeComponent();
            populateTable.print(listBox1, query1, "Pavadinimas", "Id");
            populateTable.print(listBox4, query2, "Pavadinimas", "Id");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            prodetiViena.PridetiStringID(query3, a, textBox1.Text);
            populateTable.print(listBox4, query2, "Pavadinimas", "Id");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            uzklausa2.UzklausaDuKint(query5, a, b, textBox1.Text, listBox4.SelectedValue.ToString());
         
            populateTable.print(listBox4, query2, "Pavadinimas", "Id");
        }
    }
}
