﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BendrijosKomunalinesPaslaugos
{
    public partial class Form1 : Form
    {
       // public static int NaudID ;
        Class6 class6 = new Class6();

        string a = "@a";
        string b = "@b";
        string c = "@c";


        string query = "Select * FROM Adminai a " +
            "Where a.NaudVard = @a AND a.Slaptazodis = @b";

        string query2 = "Select * FROM Vadovai a " +
            "Where a.NaudVard = @a AND a.Slaptazodis = @b";
        string query4 = "INSERT INTO DabVad VALUES ((Select a.Id FROM Vadovai a Where a.NaudVard = @a AND a.Slaptazodis = @b))";

        // "Update DabVad Set DabVadID = (Select a.Id FROM Vadovai a Where a.NaudVard = @a AND a.Slaptazodis = @b )";

        //    "INSERT INTO DabVad  " +
        // "SELECT TOP 1 (Select a.Id FROM Vadovai a Where a.NaudVard = @a AND a.Slaptazodis = @b ) FROM DabVad ";
        //"Update DabVad Set DabVadID  = (Select a.Id FROM Vadovai a Where a.NaudVard = @a AND a.Slaptazodis = @b)";
        string query5 = "INSERT INTO GyvID VALUES ((Select a.Id FROM Gyv a Where a.NaudVard = @a AND a.Slaptazodis = @b))";
        string query3 = "Select * FROM Gyv a " +
           "Where a.NaudVard = @a AND a.Slaptazodis = @b";
         
       

        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {

            Form14 bb = new Form14();
            

              try
                {

            IvykdykUzklausa2.UzklausaDuKint(query5, a, b, textBox6.Text, textBox5.Text);
            LogIn.Prisijungti(query3, a, b,  textBox6.Text, textBox5.Text, this, bb, listBox1, Convert.ToInt32(listBox1.SelectedValue));

               }
                 catch
                {
                     MessageBox.Show("Klaida");
                  }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form5 bb = new Form5();
              try
                {
            IvykdykUzklausa2.UzklausaDuKint(query4, a, b, textBox4.Text, textBox3.Text);
            LogIn.Prisijungti(query, a, b,  textBox1.Text, textBox2.Text,  this, bb, listBox1, Convert.ToInt32(listBox1.SelectedValue) ) ;
           
          }
             catch
             {
                 MessageBox.Show("Klaida");
              }


        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form11 bb = new Form11();
              try
                {
            IvykdykUzklausa2.UzklausaDuKint(query4, a, b, textBox4.Text, textBox3.Text);
            LogIn.Prisijungti(query2, a, b,  textBox4.Text, textBox3.Text,  this, bb,  listBox1, Convert.ToInt32(listBox1.SelectedValue));
            

               }
                 catch
                 {
                     MessageBox.Show("Klaida");
                  }
        }
    }
}

