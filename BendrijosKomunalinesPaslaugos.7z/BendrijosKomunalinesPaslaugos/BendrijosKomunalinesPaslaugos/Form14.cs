﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BendrijosKomunalinesPaslaugos
{
    public partial class Form14 : Form
    {
        Class6 class6 = new Class6();

        string query11 =
           " DELETE FROM GyvID WHERE Id NOT IN( 0 )";

        // string query1 = "Select * From BendrijosPaslaugosKaina a " +
        //     "INNER JOIN Paslaugos b ON a.PaslaugosID = b.Id " +
        //    "WHERE a.BendrijosID = @a AND b.VadovasID = (Select a.DabVadID FROM DabVad a) ";

        string query2 = "SELECT * FROM Paslaugos a " +
                                "INNER JOIN BendrijosPaslaugosNamas b ON a.Id = b.PaslaugosID " +
                                 "INNER JOIN Namas e ON e.Id = b.NamoID " +
                                   "INNER JOIN NamoGyventojai f ON f.NamasID = e.Id " +
                                      "Where f.GyventojasID = (Select a.DGID FROM GyvID a)";
                            //     "Where f.GyventojasID = 1";
        string query3 = "SELECT * FROM BendrijosPaslaugosKaina a " +
           "INNER JOIN Paslaugos b ON a.PaslaugosID = b.Id " +
                           "INNER JOIN BendrijosPaslaugosNamas c ON b.Id = c.PaslaugosID " +
                            "INNER JOIN Namas e ON e.Id = c.NamoID " +
                              "INNER JOIN NamoGyventojai f ON f.NamasID = e.Id " +
            // "Where f.GyventojasID = 1";
             "Where f.GyventojasID = (Select a.DGID FROM GyvID a)";
        public Form14()
        {
            InitializeComponent();
            Class2.print(listBox1, query2, "Pavadinimas", "Id");
            Class2.print(listBox2, query3, "Kaina", "Id");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            class6.Vykdyk(query11);
            Form1 b = new Form1();
            Class1.Switch(this, b);
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Class2.print(listBox1, query2, "Pavadinimas", "Id");
            Class2.print(listBox2, query3, "Kaina", "Id");
        }
    }
}
