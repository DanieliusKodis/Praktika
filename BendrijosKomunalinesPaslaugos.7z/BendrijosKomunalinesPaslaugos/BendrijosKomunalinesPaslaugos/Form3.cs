﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace BendrijosKomunalinesPaslaugos
{
    public partial class Form3 : Form
    {
        SqlConnection connection;
        string conectionString;
        public Form3()
        {
            InitializeComponent();
            conectionString = ConfigurationManager.ConnectionStrings["BendrijosKomunalinesPaslaugos.Properties.Settings.Database1ConnectionString"].ConnectionString;
            VisosBendrijos();
            VisiNamai();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void VisosBendrijos()
        {
            // sql conection need to open for qeury
            // using statmentauto closes
            using (connection = new SqlConnection(conectionString))
            using (SqlDataAdapter adapter = new SqlDataAdapter("select * from Bendrija", connection))
            {
                // sql data adapter open conector for us

                DataTable recipeTable = new DataTable();
                adapter.Fill(recipeTable);

                Bendrijos.DisplayMember = "Pavadinimas";
                Bendrijos.ValueMember = "Id";
                Bendrijos.DataSource = recipeTable;
            }

        }
        private void VisiNamai()
        {
            // sql conection need to open for qeury
            // using statmentauto closes
            using (connection = new SqlConnection(conectionString))
            using (SqlDataAdapter adapter = new SqlDataAdapter("select * from Namas", connection))
            {
                // sql data adapter open conector for us

                DataTable recipeTable = new DataTable();
                adapter.Fill(recipeTable);

                NamuAdresai.DisplayMember = "Adresas";
                NamuAdresai.ValueMember = "Id";
                NamuAdresai.DataSource = recipeTable;
            }

        }
        private void BendrijosNamai()
        {
            string query = "SELECT a.Pavadinimas FROM Bendrija a " +
                "INNER JOIN BendrijaNamas b ON b.BendrijosID= a.Id " +
                 "INNER JOIN Namas c ON c.Id = b.NamoID ";
                //  "WHERE c.Id= @i";



            using (connection = new SqlConnection(conectionString))
            using (SqlCommand comand = new SqlCommand(query, connection))
            using (SqlDataAdapter adapter = new SqlDataAdapter(comand))
            {
                // sql data adapter open conector for us
                comand.Parameters.AddWithValue("@i", Bendrijos.SelectedValue);

                DataTable recipeTable = new DataTable();
                adapter.Fill(recipeTable);

                NamuBendrijos.DisplayMember = "Pavadinimas";
                NamuBendrijos.ValueMember = "Id";
                NamuBendrijos.DataSource = recipeTable;


            }
        }

        private void pridetiBendrija()
        {
            string query = "INSERT INTO Bendrija VALUES(@RecipeName)";
            using (connection = new SqlConnection(conectionString))
            using (SqlCommand comand = new SqlCommand(query, connection))

            {
                connection.Open();
                comand.Parameters.AddWithValue("@RecipeName", textBox3.Text);


                comand.ExecuteScalar();
            }
            VisosBendrijos();
        }

        private void Bendrijos_SelectedIndexChanged(object sender, EventArgs e)
        {
            BendrijosNamai();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            pridetiBendrija();
        }

        private void button4_Click(object sender, EventArgs e)
        {
                   string a = "@a";
                   string b = "@b";
                   string query = "UPDATE Bendrija SET Pavadinimas = @a WHERE Id = @b";// change id to pavad nes kitaip bugas

                    Modifikuoti mod = new Modifikuoti();
                    mod.Modifikavimas(query, a,b,textBox3.Text, Bendrijos.SelectedIndex +1 );// change indeks to value to pavad nes kitaip bugas

            VisosBendrijos();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //      string a = "@a";
            //      string b = "@b";
            //      string c = "@c";


            string query = //"UPDATE Namas SET Adresas = @a WHERE Id = @b"+
                 "Update BendrijaNamas Set BendrijosID = @c WHERE NamoID = @b";
            ;
            //           "UPDATE BendrijaNamas SET BendrijosID = 2"                           
            // /  "INNER JOIN Bendrija ON Bendrija.Id = BendrijaNamas.BendrijosID" +
            //  "WHERE Bendrija.Pavadinimas =@c"
            ;

            //       ModifikuotiDuLaukus  mod = new ModifikuotiDuLaukus();
            //        mod.Modifikavimas2(query, a, b,c, textBox1.Text, Namas.SelectedIndex + 1, textBox2.Text);
            //        BendrijosNamai();
            //      string query = "SELECT a.Adresas FROM Namas a " +
            //      "INNER JOIN BendrijaNamas b ON b.NamoID= a.Id " +
            //        "INNER JOIN Bendrija c ON c.Id = b.BendrijosID " +
            //         "WHERE c.Id= @i";


            //   string query = "Update BendrijaNamas" +
            //        "SET BendrijaNamas.ID = (SELECT a.Id FROM Bendrija a" +
            //         "INNER JOIN BendrijaNamas b ON b.BendrijosID= a.Id" +
            //       "INNER JOIN Namas c ON c.Id = b.NamoID" +
            //       "WHERE c.Id= @b)";


            //     "WHERE (SELECT a.Pavadinimas FROM Bendrija a" +
            //     "INNER JOIN BendrijaNamas b ON b.BendrijosID= a.Id" +
            //     "INNER JOIN Namas c ON c.Id = b.NamoID" +
            //     "WHERE c.Id= @b) = @c" ;


            //      "SELECT * FROM Bendrija a " +
            //     "INNER JOIN BendrijaNamas b ON b.BendrijosID= a.Id " +
            //                       "INNER JOIN Namas c ON c.Id = b.NamoID " +
            //                     "WHERE c.Id= @b"+
            //                  "UPDATE BendrijaNamas SET Id = a.Id WHERE a.Pavadinimas = @c";
            //      "UPDATE Namas SET Adresas = @a WHERE Id = @b";


           
                
                
            //    "SELECT * FROM Bendrija a " +
          //      "INNER JOIN BendrijaNamas b ON b.BendrijosID= a.Id " +
            //                      "INNER JOIN Namas c ON c.Id = b.NamoID " +
            //                     "WHERE c.Id= @b";

                                 

            using (connection = new SqlConnection(conectionString))
            using (SqlCommand comand = new SqlCommand(query, connection))

            {
                connection.Open();
                comand.Parameters.AddWithValue("@a", textBox1.Text);
                comand.Parameters.AddWithValue("@b", NamuAdresai.SelectedValue);
                comand.Parameters.AddWithValue("@c", Bendrijos.SelectedValue);
                comand.ExecuteScalar();
            }
            BendrijosNamai();
        }

        private void Namas_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            string query =
                "INSERT INTO Bendrija " +
                "SELECT TOP 1 'Klaida-Nepriskirta-Klaida' FROM Bendrija WHERE not exists (Select a.Pavadinimas FROM Bendrija a WHERE a.Pavadinimas = 'Klaida-Nepriskirta-Klaida')" +
           "Update BendrijaNamas Set BendrijosID =  (Select a.Id FROM Bendrija a WHERE a.Pavadinimas = 'Klaida-Nepriskirta-Klaida')" +
           " WHERE BendrijosID = @i " +
                "Update BendrijosPaslaugos Set BendrijosID  = (Select a.Id FROM Bendrija a WHERE a.Pavadinimas = 'Klaida-Nepriskirta-Klaida')" +
                " WHERE BendrijosID = @i " +
              "DELETE FROM Bendrija WHERE Id = @i AND Pavadinimas != 'Klaida-Nepriskirta-Klaida'";
             
               
            using (connection = new SqlConnection(conectionString))
            using (SqlCommand comand = new SqlCommand(query, connection))

            {
                connection.Open();
                comand.Parameters.AddWithValue("@i", Bendrijos.SelectedValue);


                comand.ExecuteScalar();
            }
            VisosBendrijos();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            
            Class1 class1 = new Class1();
            Form4 b = new Form4();
            Class1.Switch(this, b);
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
//string query =
      //          "UPDATE BendrijaNamas SET BendrijosID = 2 WHERE Id = 1" +
      //          "UPDATE Namas SET Adresas = @a WHERE Id = @b";