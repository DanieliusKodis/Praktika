﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BendrijosKomunalinesPaslaugos
{
    public partial class Form7 : Form
    {
        Class1 class1 = new Class1();
        Class2 populateTable = new Class2();
        Prideti pridetiViena = new Prideti();
        IvykdykUzklausa2 uzklausa2 = new IvykdykUzklausa2();
        Class3 class3 = new Class3();
       
        Class5 class5 = new Class5();
        PridetiINT pridetiINT = new PridetiINT();
        IntInt intInt = new IntInt();

        string a = "@a";
        string b = "@b";
        string c = "@c";

      //  string query1 = "Select * FROM Vadovai ";

           
        string query2 = "Select * FROM Paslaugos ";
        string query6 = "SELECT * FROM Paslaugos a " +
                  "INNER JOIN BendrijosPaslaugosKaina b ON a.Id = b.PaslaugosID " +
            "INNER JOIN Bendrija c ON c.id = b.BendrijosID " +
                  "WHERE c.Id = @a";
        string query3 = "INSERT INTO Paslaugos " +
             "SELECT TOP 1 @a, NULL FROM Paslaugos WHERE not exists (Select a.Pavadinimas FROM Paslaugos a WHERE a.Pavadinimas = @a) ";
        string query5 = "Update Paslaugos Set Pavadinimas = @a WHERE Id = @b AND not exists (Select a.Pavadinimas FROM Paslaugos a WHERE a.Pavadinimas = @a)";
        string query9 = "INSERT INTO Paslaugos " +
              "SELECT TOP 1 'Klaida-Nepriskirta-Klaida', NULL FROM Paslaugos WHERE not exists (Select a.Pavadinimas FROM Paslaugos a WHERE a.Pavadinimas = 'Klaida-Nepriskirta-Klaida') " +//AND exists (Select a.PaslaugosID FROM BendrijosPaslaugosNamas a WHERE a.PaslaugosID = @a)
                                                                                                                                                                                      //  "Update BendrijosPaslaugosNamas Set PaslaugosID =  (Select a.Id FROM Paslaugos a WHERE a.Pavadinimas = 'Klaida-Nepriskirta-Klaida')" +
                                                                                                                                                                                      //   " WHERE PaslaugosID = @a " +
              "Update BendrijosPaslaugos Set PaslaugosID  = (Select a.Id FROM Paslaugos a WHERE a.Pavadinimas = 'Klaida-Nepriskirta-Klaida')" +
              " WHERE PaslaugosID = @a " +
         "Update BendrijosPaslaugosKaina Set PaslaugosID =  (Select a.Id FROM Paslaugos a WHERE a.Pavadinimas = 'Klaida-Nepriskirta-Klaida')" +
         " WHERE PaslaugosID = @a " +
            "Update BendrijosPaslaugosNamas Set PaslaugosID =  (Select a.Id FROM Paslaugos a WHERE a.Pavadinimas = 'Klaida-Nepriskirta-Klaida')" +
         " WHERE PaslaugosID = @a " +
           "DELETE FROM Paslaugos WHERE Id = @a AND Pavadinimas != 'Klaida-Nepriskirta-Klaida'";
        string query10 =
           "INSERT INTO BendrijosPaslaugosKaina " +
            "SELECT TOP 1 @a, @b, NULL FROM BendrijosPaslaugosKaina WHERE not exists (Select * FROM BendrijosPaslaugosKaina a Where a.BendrijosID = @a AND a.PaslaugosID = @b ) "
           ;
        string query11 =
       
            "DELETE FROM BendrijosPaslaugosKaina WHERE BendrijosID = @a AND PaslaugosID = @b";
        public Form7()
        {
            InitializeComponent();
            Class2.print(listBox4, query2, "Pavadinimas", "Id");
         //   Class2.print(listBox1, query1, "Vardas", "Id");
            Class3.RodytiPagalID(listBox2, "Pavadinimas", "Id", query6, a, Form5.BendrijosID.ToString());

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Prideti.PridetiStringID(query3,a,textBox1.Text);
            Class2.print(listBox4, query2, "Pavadinimas", "Id");
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            IvykdykUzklausa2.UzklausaDuKint(query5, a, b, textBox1.Text, listBox4.SelectedValue.ToString());

            Class2.print(listBox4, query2, "Pavadinimas", "Id");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pridetiINT.PridetiStringINTid(query9, a, Convert.ToInt32(listBox4.SelectedValue));
            Class2.print(listBox4, query2, "Pavadinimas", "Id");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            intInt.PridetiStringINTINTid(query10,a,b, Form5.BendrijosID, Convert.ToInt32(listBox4.SelectedValue));        
            Class3.RodytiPagalID(listBox2, "Pavadinimas", "Id", query6, a, Form5.BendrijosID.ToString());
        }

        private void button6_Click(object sender, EventArgs e)
        {
            intInt.PridetiStringINTINTid(query11, a, b, Form5.BendrijosID, Convert.ToInt32(listBox2.SelectedValue));
            Class3.RodytiPagalID(listBox2, "Pavadinimas", "Id", query6, a, Form5.BendrijosID.ToString());
        }

        private void listBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            Form10 b = new Form10();
            Class1.Switch(this, b);
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            Form5 b = new Form5();
            Class1.Switch(this, b);
        }
    }
}
