﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BendrijosKomunalinesPaslaugos
{
    class Class1
    {
        public static void Switch(Form a, Form b)
        {
            a.Hide();

            b.ShowDialog();
            b.Close();


        }
    }
}
