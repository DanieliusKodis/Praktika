﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
namespace BendrijosKomunalinesPaslaugos
{
    class IntInt
    {
        public void PridetiStringINTINTid(string query, string fromQeury, string fromQeury2, int id, int id2)
        {
            SqlConnection connection;
            string conectionString;
            conectionString = ConfigurationManager.ConnectionStrings["BendrijosKomunalinesPaslaugos.Properties.Settings.Database1ConnectionString"].ConnectionString;



            using (connection = new SqlConnection(conectionString))
            using (SqlCommand comand = new SqlCommand(query, connection))

            {
                connection.Open();
                comand.Parameters.AddWithValue(fromQeury, id);
                comand.Parameters.AddWithValue(fromQeury2, id2);

                comand.ExecuteScalar();
            }

        }
    }
}
