﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BendrijosKomunalinesPaslaugos
{
    public partial class Form8 : Form
    {
        Class1 class1 = new Class1();
        Class2 populateTable = new Class2();
        Prideti pridetiViena = new Prideti();
        IvykdykUzklausa2 uzklausa2 = new IvykdykUzklausa2();
        Class3 class3 = new Class3();
      
        Class5 class5 = new Class5();
        PridetiINT pridetiINT = new PridetiINT();
        IntInt intInt = new IntInt();
        Modifikuoti mod = new Modifikuoti();

        string a = "@a";
        string b = "@b";
        string c = "@c";

        string query2 = "Select * FROM Bendrija";
        string query3 = "Select * FROM Namas";
        string query4 = "INSERT INTO Namas " +
            "SELECT TOP 1 @a FROM Namas WHERE not exists (Select a.Adresas FROM Namas a WHERE a.Adresas = @a) " +
            "INSERT INTO BendrijosPaslaugosNamas VALUES(@b, NULL,(Select a.Id FROM Namas a WHERE a.Adresas = @a) ) ";
        string query7 = "Update NamoGyventojai Set NamasID = (NULL)" +
                       "WHERE NamasID = @a " +
            "Update BendrijosPaslaugosNamas Set NamoID  = (NULL)" +
                       "WHERE NamoID = @a " +
 "DELETE FROM Namas " +
 "WHERE Namas.Id = @a";

        public Form8()
        {
            InitializeComponent();
            Class2.print(listBox1, query2, "Pavadinimas", "Id");
            Class2.print(listBox2, query3, "Adresas", "Id");
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            mod.Modifikavimas(query4,a,b,textBox1.Text, Convert.ToInt32(listBox1.SelectedValue));
            Class2.print(listBox2, query3, "Adresas", "Id");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pridetiINT.PridetiStringINTid(query7, a, Convert.ToInt32(listBox2.SelectedValue));
            Class2.print(listBox2, query3, "Adresas", "Id");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form5 b = new Form5();
            Class1.Switch(this, b);
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
